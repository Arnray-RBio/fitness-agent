PERMANENT BRAND AND BRANCH REGISTER

Before starting
Stop running Streamlit apps using Ctrl+C. Do not run a collection/import during backup.
In C:\Users\arnab\fitness-agent:
  copy data\fitness_agent.db data\fitness_agent_before_registry.db
If that backup already exists, use a new backup filename instead of overwriting it.

Copy registry_app.py and registry_store.py into C:\Users\arnab\fitness-agent.
Keep overview_app.py there; this register reuses its capture grouping and loading.
No existing scripts are replaced. No new dependencies are needed.

Run
  .venv313\Scripts\python.exe -m streamlit run registry_app.py
Open the URL printed in CMD.

The first launch adds four tables to your existing SQLite database:
registry_brands, registry_branches, registry_links, registry_revisions.
Existing capture/review tables and records are preserved.

First test
1. Open Link capture candidates.
2. Choose Sochill's latest branch candidate.
3. Choose Create a new branch. Enter/reuse the brand Sochill Bath Club.
4. Check the name and address against saved evidence. Include #02-01 if supported.
5. Leave operating status unknown. Categories can remain empty until verified.
6. Confirm it is a distinct location and create the record.
7. Refresh. You should see one permanent branch with one observation.
8. Check Include historical captures and choose another observation of that same
   location. Link it to the existing branch, confirming the physical match.
9. The permanent branch total should remain one; linked observations should rise.
Do not create a second location merely because a capture uses a different name.

Editing
Branch register shows each permanent location. Edit and save details there.
Address and name evidence are required when relevant. Categories require evidence
for services at that specific branch. Status other than unknown requires evidence,
a verification URL and a date. All saved register revisions are preserved.
Capture reviews remain separate: changes there do not automatically overwrite the
register. Linking observations also leaves the register profile unchanged.

Identity
Brand names are normalized for case and whitespace. Similar spellings still need
manual resolution. Duplicate branch names and exact normalized addresses within
one brand are blocked. Near-duplicate addresses/spellings are not automatically
resolved; compare existing records before creating anything. Different units may
represent different locations, so keep full unit details.

Counts
Counts cover only registered locations and recorded status. No freshness threshold
is implemented yet. Old verification must be reviewed before using operating
counts as current facts. Category totals overlap for mixed facilities and must not
be added to obtain a unique physical location total. These are not Singapore-wide
counts. Rejected capture reviews are omitted from the candidate picker.

Scope
No automatic merging, branch deletion, observation reassignment, new manual branch
entry, or brand renaming in this first version. If you link the wrong record, stop
and report it so a correction can preserve history. A new review version creates
another observation candidate; link it to the established branch.
No proximity/geocoding, daily count snapshots, scheduling or change detection yet.

Validation
Syntax checks and simulated SQLite tests passed for creation, repeat linking,
duplicate prevention, rollback, evidence requirements, preservation of established
status, stale-edit detection, revision history and original capture preservation.
The Streamlit interface needs a local test on your Windows computer.
